import cv2
import numpy as np
import sys

def get_color_grid(image_path, cell_size=16, draw_grid=False):
    """
    Estrae una matrice di colori HEX da un'immagine divisa in griglia.
    
    Args:
        image_path (str): Percorso dell'immagine
        cell_size (int): Dimensione di ogni cella in pixel
        draw_grid (bool): Se True, mostra l'immagine con la griglia
    
    Returns:
        list: Matrice 2D di stringhe HEX (es: [["#FF0000", "#00FF00"], ...])
    """
    image = cv2.imread(image_path)
    if image is None:
        print(f"Errore: Impossibile caricare l'immagine da {image_path}")
        return None

    h, w = image.shape[:2]
    cells_x = w // cell_size
    cells_y = h // cell_size
    
    # Crea la matrice dei colori
    color_matrix = []
    
    for i in range(cells_y):
        row = []
        for j in range(cells_x):
            # Area della cella
            x1 = j * cell_size
            y1 = i * cell_size
            x2 = (j + 1) * cell_size
            y2 = (i + 1) * cell_size
            
            # Estrai la regione di interesse
            cell = image[y1:y2, x1:x2]
            
            # Calcola il colore medio (anziché solo il pixel centrale)
            mean_color = np.mean(cell, axis=(0, 1)).astype(int)
            b, g, r = mean_color
            
            # Converti in HEX
            hex_color = f"#{r:02x}{g:02x}{b:02x}".upper()
            row.append(hex_color)
            
            # Se richiesto, disegna la griglia
            if draw_grid:
                cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 1)
                cv2.putText(image, hex_color, (x1 + 2, y1 + 12), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0, 0, 255), 1)
        
        color_matrix.append(row)
    
    if draw_grid:
        cv2.imshow(f"Grid {cells_x}x{cells_y}", image)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    
    return color_matrix


def main():
    if len(sys.argv) < 2:
        print("Usage: python import_cv2.py <image_path> [cell_size]")
        return

    image_path = sys.argv[1]
    cell_size = int(sys.argv[2]) if len(sys.argv) > 2 else 16

    colori = get_color_grid(image_path, cell_size=cell_size)
    print(colori)

if __name__ == "__main__":
    main()
   