"use strict";

const output = document.getElementById('output');
var start = false;
let bottoni = {};
var t1 = false;
var t2 = false;
var twin = false;

const player = {
    "nome": "",
    "gravita": 0.3,
    "velocita": 1,
    "salto": 8,
    "pos_x": 0,
    "pos_y": 846,
    "path": "./res/beluga.png"
};

class Campo {
    constructor(nome_campo) {
        this.nome_campo = nome_campo;
        this.campo = new Array(16);
        
        for (let i = 0; i < 16; i++) {
            this.campo[i] = new Array(64).fill(null);
        }

        for (let i = 0; i < 16; i++) {
            for (let j = 0; j < 64; j++) {
                if (i < 2) {
                    this.campo[i][j] = '#5C94FC';
                } else if (i === 2) {
                    this.campo[i][j] = '#455EF0';
                } else if (i >= 3 && i < 12) {
                    this.campo[i][j] = '#2038EC';
                } else {
                    this.campo[i][j] = '#2C9131';
                }
            }
        }
    }

    set_player() {
        const imgPlayer = document.getElementById('img-player');
        if (imgPlayer) {
            imgPlayer.style.left = player.pos_x + 'px';
            imgPlayer.style.top = player.pos_y + 'px';
        }
    }

    set_player_pos(x, y) {
        x = clampedposition(x, 0, 1893);
        y = clampedposition(y, 615, 846);
        
        player.pos_x = x;
        player.pos_y = y;

        if (player.pos_x >= 333 && !t1) {
            t1 = true;
            document.cookie = "step=2; path=/";
            this.updateCookie_percorso();
        }
        if (player.pos_x >= 995 && !t2) {
            t2 = true;
            document.cookie = "step=3; path=/";
            this.updateCookie_percorso();
        }
        if (player.pos_x >= 1503 && !twin) {
            twin = true;
            document.cookie = "step=4; path=/";
            const livelloElem = document.getElementById("livello");
            const user = document.getElementById("username");
            if (user) {
                user.textContent = "";
            }
            if(livelloElem) {
                livelloElem.textContent = "HAI VINTO!";
                livelloElem.style.color = "red";
                livelloElem.style.fontSize = "30px";
                livelloElem.style.fontWeight = "bold";
                livelloElem.style.textAlign = "center";
                livelloElem.style.position = "absolute";
                livelloElem.style.top = "30%";
                livelloElem.style.left = "50%";
                livelloElem.style.transform = "translate(-50%, -50%)";
            }
        }
        
        this.set_player();
    }

    set_player_gravita() {
        const gravitaInterval = setInterval(() => {
            if (player.pos_y < 846) {
                player.pos_y += player.gravita;
                if (player.pos_y > 846) player.pos_y = 846;
                this.set_player();
            } else {
                clearInterval(gravitaInterval);
            }
        }, 16);
    }

    updateCookie_percorso() {
        const livelloElem = document.getElementById("livello");
        if (livelloElem) {
            const livelloMatch = document.cookie.match(/livello=(\d+)/);
            const stepMatch = document.cookie.match(/step=(\d+)/);
            const livello = livelloMatch ? livelloMatch[1] : "1";
            const step = stepMatch ? stepMatch[1] : "0";
            livelloElem.textContent = "Sei al livello " + livello + " allo step " + step;
        }
    }
}

window.onload = function() {    
    const campo1 = new Campo("campo1");
    campo1.set_player();
    start = true;
    Inserisci_nome();

    // Inizializzazione cookie
    if (!document.cookie.match(/livello=/)) {
        document.cookie = "livello=1; path=/";
    }
    if (!document.cookie.match(/step=/)) {
        document.cookie = "step=1; path=/";
    }

    // Leggi lo step corrente
    const stepMatch = document.cookie.match(/step=(\d+)/);
    const step = stepMatch ? stepMatch[1] : "1";

    // Imposta le variabili di stato in base allo step
    t1 = (step >= "2");
    t2 = (step >= "3");
    twin = (step === "4");

    // Posiziona il player in base allo step
    if (step === "4") {
        //resetta i cookie
                document.cookie = "livello=1; path=/";
                document.cookie = "step=1; path=/";
                document.cookie = "nome=; path=/";
                //ricarica la pagina
                window.location.reload();
    } else if (step === "3") {
        campo1.set_player_pos(995+27, player.pos_y);
    } else if (step === "2") {
        campo1.set_player_pos(333+27, player.pos_y);
    } else {
        campo1.set_player_pos(0, player.pos_y);
    }

    document.getElementById("username").textContent = "Benvenuto "+player.nome;
    campo1.updateCookie_percorso();
    
    function Inserisci_nome(){
        const nomeMatch = document.cookie.match(/nome=([a-zA-Z0-9]{1,5})/);
        
        if (nomeMatch) {
            player.nome = nomeMatch[1];
        } else {
            let nome;
            let nomeValido = false;
            
            while (!nomeValido) {
                nome = prompt("Inserisci il tuo nome (max 5 caratteri alfanumerici):");
                
                if (nome === null) {
                    nome = "user";
                    nomeValido = true;
                } else {
                    nome = nome.trim().substring(0, 5);
                    if (nome.length > 0 && nome.match(/^[a-zA-Z0-9]+$/)) {
                        nomeValido = true;
                    } else {
                        alert("Nome non valido! Solo lettere e numeri, max 5 caratteri.");
                    }
                }
            }
            
            player.nome = nome;
            document.cookie = `nome=${nome}; path=/; max-age=${30*24*60*60}`;
        }
        
        document.getElementById("username").textContent = player.nome;
    }

    document.addEventListener('keydown', (event) => {
        bottoni[event.key] = true;
    });

    document.addEventListener('keyup', (event) => {
        bottoni[event.key] = false;
    });

    function loop(){
        if(bottoni['a']|| bottoni['A'] || bottoni['ArrowLeft']){
            campo1.set_player_pos(player.pos_x-2, player.pos_y);     
        }
        if(bottoni['s'] || bottoni['S'] || bottoni['ArrowDown']){
            campo1.set_player_pos(player.pos_x, player.pos_y + 2);      
        }
        if(bottoni['d']|| bottoni['D'] || bottoni['ArrowRight']){
            campo1.set_player_pos(player.pos_x+2, player.pos_y);     
        }
        if (bottoni[' ']){
            campo1.set_player_pos(player.pos_x, player.pos_y - player.salto); 
            campo1.set_player_gravita();
        }

        requestAnimationFrame(loop);
    }

    loop();
}

function clampedposition(value, min, max) {
    if (value < min) {
        return min;
    }
    if (value > max) {
        return max;
    }
    return value;
}