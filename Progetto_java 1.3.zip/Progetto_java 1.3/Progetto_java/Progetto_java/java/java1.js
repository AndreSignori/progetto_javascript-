function startGame() {
    window.location.href = "game.html";
}

document.addEventListener('keydown', () => {
    startGame();
});

document.addEventListener('click', () => {
    startGame();
});
