"use strict";

const output = document.getElementById('output');
var start = false;

const player = {
    "nome": "player",
    "gravita": 1,
    "velocita": 1,
    "salto": 1,
    "pos_x": 0,
    "pos_y": 846,
    "path": "./res/beluga.png"
};

class Campo {
    constructor(nome_campo) {
        this.nome_campo = nome_campo;
        this.campo = new Array(16);
        
        for (let i = 0; i < 16; i++) {
            this.campo[i] = new Array(64).fill(null);
        }

        // Inizializza il campo (come nel tuo codice originale)
        for (let i = 0; i < 16; i++) {
            for (let j = 0; j < 64; j++) {
                if (i < 2) {
                    this.campo[i][j] = '#5C94FC';
                } else if (i === 2) {
                    this.campo[i][j] = '#455EF0';
                } else if (i >= 3 && i < 12) {
                    this.campo[i][j] = '#2038EC';
                } else {
                    this.campo[i][j] = '#2C9131';
                }
            }
        }
        
        // Aggiungi qui gli altri elementi del campo come nel tuo codice originale
    }

    set_player() {
        const imgPlayer = document.getElementById('img-player');
        if (imgPlayer) {
            imgPlayer.style.left = player.pos_x + 'px';
            imgPlayer.style.top = player.pos_y + 'px';
        }
    }

    set_player_pos(x, y) {

        x=clampedposition(x, 0, 1893);
        y=clampedposition(y, 615, 846);
        
        player.pos_x = x;
        player.pos_y = y;
        
        // Aggiorna la posizione del giocatore
        this.set_player();
    }
    
}

// Listener per TASTIERA
document.addEventListener('keydown', (event) => {
    
});

window.onload = function() {
    const game = new Campo("campo1");
    game.set_player();
    start = true;
    document.cookie = "step=0; path=/";
    
    // Listener per i controlli di gioco
    document.addEventListener('keydown', (event) => {
        switch(event.key) {
            case 'ArrowLeft':
            case 'a':
                game.set_player_pos(player.pos_x - 1, player.pos_y);
                break;
            case 'ArrowRight':
            case 'd':
                game.set_player_pos(player.pos_x + 1, player.pos_y);
                break;
            case 'ArrowUp':
            case 'w':
                game.set_player_pos(player.pos_x, player.pos_y - 1);
                break;
            case 'ArrowDown':
            case 's':
                game.set_player_pos(player.pos_x, player.pos_y + 1);
                break;
        }
    });
};


function clampedposition(value, min, max) {
    if (value < min) {
        return min;
    }
    if (value > max) {
        return max;
    }
    return value;
}